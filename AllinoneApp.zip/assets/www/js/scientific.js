var inputLabel = document.getElementById('inputLabel');

var inputLabel2 = document.getElementById('inputLabel2');
var pre;

   var b=1;


function pushBtn(obj) {


   
 
   var pushed = obj.innerHTML;

 
    
         

if (pushed == '='){
    

   
    
    
     navigator.vibrate(100);
    

            if(b==2)
                {
            
    
            inputLabel.innerHTML=f1();
           
    var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
                    
        }
    else if(b==3)
        {
           
 
            inputLabel.innerHTML=f3();
           
    var ff =pre+inputLabel.innerHTML;
            b=1;
            inputLabel.innerHTML=ff;
            
            }
      else if(b==4)
        {
            inputLabel.innerHTML=f4();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
      else if(b==5)
        {
            inputLabel.innerHTML=f5();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
     else if(b==6)
        {
            inputLabel.innerHTML=f6();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
     else if(b==7)
        {
            inputLabel.innerHTML=f7();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
    
    
    
    
      else if(b==8)
        {
            inputLabel.innerHTML=f8();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
    
    
    else if(b==9)
        {
            inputLabel.innerHTML=f9();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
      else if(b==10)
        {
            inputLabel.innerHTML=f10();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
    
      else if(b==11)
        {
           
            inputLabel.innerHTML=f11();
            var ff =pre+inputLabel.innerHTML;
        
            b=1;
            inputLabel.innerHTML=ff;
                    inputLabel2.innerHTML=inputLabel.innerHTML;
            }
    
else{
    if(b == 1){
        
    
    
    inputLabel.innerHTML=f2();
     inputLabel2.innerHTML=inputLabel.innerHTML;
    
}

}}

         

 


           


else  if(pushed == 'SIN')
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 2;

      
}else {pre=inputLabel.innerHTML;
   b = 2;
inputLabel.innerHTML="";}
      
   if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="SIN(";}
    else{
        inputLabel2.innerHTML=pre+"SIN(";
    }
}

    else  if(pushed == 'COS')
{
     
 if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 3;

      
}else {pre=inputLabel.innerHTML;
   b = 3;
inputLabel.innerHTML="";}
      
      
  if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="COS(";}
    else{
        inputLabel2.innerHTML=pre+"COS(";
    }
}
    else  if(pushed == 'TAN')
{
     

if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 4;

      
}else {pre=inputLabel.innerHTML;
   b = 4;
inputLabel.innerHTML="";}
      
      
  if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="TAN(";}
    else{
        inputLabel2.innerHTML=pre+"TAN(";
    }

}
    else  if(pushed == 'SINH')
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 5;

      
}else {pre=inputLabel.innerHTML;
   b = 5;
inputLabel.innerHTML="";}
      
   if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="SINH(";}
    else{
        inputLabel2.innerHTML=pre+"SINH(";
    }
}
    
       else  if(pushed == 'COSH')
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 6;

      
}else {pre=inputLabel.innerHTML;
   b = 6;
inputLabel.innerHTML="";}
      
   if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="COSH(";}
    else{
        inputLabel2.innerHTML=pre+"COSH(";
    }
}

    
    
     else  if(pushed == 'TANH')
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 7;

      
}else {pre=inputLabel.innerHTML;
   b = 7;
inputLabel.innerHTML="";}
      
   if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="TANH(";}
    else{
        inputLabel2.innerHTML=pre+"TANH(";
    }
}
    
    
        else  if(pushed == document.getElementById("sqrt").innerHTML)
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 8;

      
}else {pre=inputLabel.innerHTML;
   b = 8;
inputLabel.innerHTML="";}
    
  if(inputLabel2.innerHTML == ''){
      
      
      inputLabel2.innerHTML="&#8730;X";}
  else{
       inputLabel2.innerHTML=pre+"&#8730;X";
   }
}

    
    
    
           else  if(pushed == document.getElementById("sq").innerHTML)
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 9;

      
}else {pre=inputLabel.innerHTML;
   b = 9;
inputLabel.innerHTML="";}
    
  if(inputLabel2.innerHTML == ''){
      
  
      inputLabel2.innerHTML="X&#178;";}
  else{
       inputLabel2.innerHTML=pre+"X&#178;";
   }
}
    
    
        
     else  if(pushed == 'LOG')
{
     
 
  if(inputLabel.innerHTML=='0')
   
{
   pre="";
   b = 10;

      
}else {pre=inputLabel.innerHTML;
   b = 10;
inputLabel.innerHTML="";}
      
   if(inputLabel2.innerHTML == ''){inputLabel2.innerHTML="LOG(";}
    else{
        inputLabel2.innerHTML=pre+"LOG(";
    }
}
    
    
    else if(pushed=='DEL')
        {
            
            
           
            
            if(inputLabel.innerHTML=='0')
                {
                    
                
                }
            else{
                 inputLabel.innerHTML=inputLabel.innerHTML.substr(0,inputLabel.innerHTML.length-1);
                
            }
            
            
            
            
            
            
        }
    
    
    
    

else if (pushed == 'AC') {

inputLabel.innerHTML = '0';
    inputLabel2.innerHTML="";
  
b=1;
} else {
        if (inputLabel.innerHTML == '0') 
        {
inputLabel.innerHTML = pushed;

} 
    else
    {
inputLabel.innerHTML = inputLabel.innerHTML+pushed;

}
}

   
}
function f1()
{
   

var ans=Math.sin(inputLabel.innerHTML*Math.PI/180);
 var fix= ans.toFixed(3);
    
    return fix;
}
   
    
    function f2()
{
    
   
    var ans = eval(inputLabel.innerHTML);
    return ans;
}
    function f3()
{
    
    

    var ans = Math.cos(inputLabel.innerHTML*Math.PI/180);
var fix= ans.toFixed(3);
    
    return fix;
    
}
    function f4()
{
    var ans = Math.tan(inputLabel.innerHTML*Math.PI/180);
    var fix= ans.toFixed(3);
    
    return fix;
    
}
    function f5()
{
    var ans = Math.sinh(inputLabel.innerHTML*Math.PI/180);
    var fix= ans.toFixed(3);
    
    return fix;
    
}
        function f6()
{
    var ans = Math.cosh(inputLabel.innerHTML*Math.PI/180);
    var fix= ans.toFixed(3);
    
    return fix;
    
}
    
    
        function f7()
{
    var ans = Math.tanh(inputLabel.innerHTML*Math.PI/180);
    var fix= ans.toFixed(3);
    
    return fix;
    
}
        function f8()
{
    var ans = Math.sqrt(inputLabel.innerHTML);
 
    var fix= ans.toFixed(3);
    
    return fix;
    
}
         function f9()
{
    var ans = Math.pow((inputLabel.innerHTML),2);
 
    var fix= ans.toFixed(3);
    
    return fix;
    
}
          function f10()
{
    var ans = Math.log10(inputLabel.innerHTML);
 
    var fix= ans.toFixed(3);
    
    return fix;
    
}
  
    












