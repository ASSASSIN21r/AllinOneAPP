var inputLabel = document.getElementById('inputLabel');

function pushBtn(obj) {

var pushed = obj.innerHTML;

if (pushed == '=') {
         navigator.vibrate(100);

inputLabel.innerHTML = eval(inputLabel.innerHTML);

} 
    else if(pushed=='DEL')
        {
            
            
           
            
            if(inputLabel.innerHTML=='0')
                {
                    
                
                }
            else{
                 inputLabel.innerHTML=inputLabel.innerHTML.substr(0,inputLabel.innerHTML.length-1);
                
            }}
            
    
    else if (pushed == 'AC') {

inputLabel.innerHTML = '0';

} else {if (inputLabel.innerHTML == '0') {
inputLabel.innerHTML = pushed;

}
    
    
    else {
inputLabel.innerHTML = inputLabel.innerHTML+pushed;

}
}
}